

Resource::Resource(std::string image, Point size, Point position,  float value,std::string type)
    :Sprite(image,size,position), type{type}
{

}
