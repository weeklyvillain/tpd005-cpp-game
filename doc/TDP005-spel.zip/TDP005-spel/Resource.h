#pragma once

class Resource : public Sprite
{
public:
    Resource(std::string, Point, Point, float,std::string );
    std::string type;
    float value;
private:

};

#include "Resource.cpp"
