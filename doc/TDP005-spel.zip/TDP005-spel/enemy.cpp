#include <iostream>

Enemy::Enemy(std::string image, Point size, Point position)
    :Entity(image,size,position)

{

}

bool Enemy::move(int time)
{
    //Create random movement behaviour
    int random = rand() % 3 + (-1);
    Point newpos;
    newpos.x = getPosition().x;
    newpos.y = getPosition().y;
    newpos.x = getPosition().x + random * speed.x ;
    update(newpos);
    return 0;
}

Projectile * Enemy::attack()
{

    Point entityPosition = getPosition();
    Point spawnPosition = Point{entityPosition.x + getSize().x - 50, (entityPosition.y + (getSize().y /2) ) };
    Projectile * proj = new Projectile("projectile.png", Point{60.0,50.0}, spawnPosition,1,Point{-20.0,0});

    int random = rand() % 40 +1;

    if(random == 5)
        return proj;
    else
        return nullptr;

}



