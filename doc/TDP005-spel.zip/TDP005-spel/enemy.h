#pragma once
#include "entity.h"
#include <cstdlib>
class Enemy : public Entity
{
public:
    Enemy(std::string , Point, Point);
            Enemy() = default;
    bool move(int) override;
    Projectile * attack() override;

private:

protected:

};

#include "enemy.cpp"
