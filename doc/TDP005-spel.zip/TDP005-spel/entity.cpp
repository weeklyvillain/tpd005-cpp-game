
Entity::Entity(std::string image, Point size, Point position)
: Sprite(image,size,position)
{
	init();
}

void Entity::init()
{
	dead = false;
	health = 100;
             defaultPosition = position;
}

bool Entity::move(int time){return 0;}

Projectile * Entity::attack(){}

bool Entity::collide(Sprite * object)
{
    bool willCollide = (object->getRight() >= getCenterX() && object->getLeft() <= getCenterX() && object->getBottom() >= getTop() && object->getTop() <= getBottom());


     return willCollide;
}

bool Entity::collide(Resource * object)
{
    bool willCollide = (object->getRight() >= getCenterX() && object->getLeft() <= getCenterX() && object->getBottom() >= getTop() && object->getTop() <= getBottom());

     if(willCollide)
    {
        if(object->type == "health")
        {
            std::cout << "health";
            health+= object->value;
            sf::Color c(50, 50, 50);
            sprite.setColor(c);
        }
        else if(object->type == "ammo")
        {
            ammunition += object->value;
        }
    }

    return willCollide;
}

bool Entity::collide(Platform * object, std::vector<Platform*> platforms)
{

    bool willCollide = (object->getRight() >= getLeft() && object->getLeft() <= getCenterX() && object->getBottom() >= getTop() && object->getTop() <= getBottom());

     if(willCollide && object !=myPlatform)
    {
        blockingPlatform = object;
        //If blocking object is on right side of entity
         if(object->getRight() > getRight())
            canMoveRight = false;
        else
            canMoveLeft = false;
    }
    //If the platform that was blocking no longer blocks
    else if(object == blockingPlatform)
    {
        canMoveLeft = true;
        canMoveRight = true;
    }

    if(object->isOnMe(this))
    {
        if(myPlatform == nullptr)
        {
        std::cout << "test";
        myPlatform = object;
        fallingFromPlatform = nullptr;
        Point newpos;
        newpos.x = getPosition().x;
        newpos.y = (object->getPosition().y - getSize().y);
        update(newpos);
        interruptJump = true;
        }
    }
    //if entity fall down from platform
    else if(myPlatform == object)
    {
        fallingFromPlatform = myPlatform;
        myPlatform = nullptr;

    }
    //If no platform to land on was found
    else if(fallingFromPlatform == object)
    {
        Point newpos;
        newpos.x = getPosition().x;
        newpos.y =  defaultPosition.y;
        fallingFromPlatform = nullptr;
        update(newpos);

    }
     return willCollide;
    }


void Entity::takeDamage(int damage)
{
if(color > 100 && health < 60)
{
    color -= 2;
    sf::Color c(color, 0, 0);
    sprite.setColor(c);
}
 health-=damage;
 //Limit how much you can slow
 if(speed.x - 0.1 > 0.5)
    speed.x -= 0.1;
}
