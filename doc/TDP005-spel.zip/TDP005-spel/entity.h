#pragma once
#include "sprite.h"
#include "projectile.h"
#include "platform.h"
#include "Resource.h"

struct Direction
{
	float x;
	float y;
};

class Entity : public Sprite
{
public:
    Entity(std::string , Point , Point );
    Entity() = default;
    Direction speed{1.0,0};
    int health {100};
    double dead;
    virtual bool move(int);
    virtual Projectile * attack();
    bool collide(Sprite*  );
    bool collide(Platform* , std::vector<Platform*>);
    bool collide(Resource *);
    void takeDamage(int );


protected:
    bool canMoveLeft = true;
    bool canMoveRight = true;
    bool interruptJump = false;
    Point defaultPosition;
    Platform * myPlatform = nullptr; // The platform the entity is standing on
    Platform * fallingFromPlatform = nullptr;
    Platform * blockingPlatform = nullptr; // Platform blocking entitys path
    int ammunition{0};

private:
void init();

};
#include "entity.cpp"
