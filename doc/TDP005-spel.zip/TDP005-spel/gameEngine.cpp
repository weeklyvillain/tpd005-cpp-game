#include "gameEngine.h"
#include <thread>

//Kompilera med : g++ -g -pthread -Wall -std=c++11 gameEngine.cpp -lsfml-graphics -lsfml-window -lsfml-system -o  sfml


int main()
{
    sf::RenderWindow window{sf::VideoMode(1024,768),"Galet roligt spel"};
    window.setFramerateLimit(144);

    GameEngine game;
    game.startGame(window);
    return 0;
}

GameEngine::GameEngine()

{

}

void GameEngine::initGame(sf::RenderWindow & window)
{

    Point playerPos;
    playerPos.x = 200;
    playerPos.y = window.getSize().y -150;
    Player*  p = new Player("player.png",Point{180,150}, playerPos);
    player = p;
    Enemy* e = new Enemy("enemy.png", Point{120,150}, Point{500,window.getSize().y -150});
    Enemy* e2 = new Enemy("enemy.png", Point{120,150}, Point{600,window.getSize().y -150});
    Enemy* e3 = new Enemy("enemy.png", Point{120,150}, Point{800,window.getSize().y -150});

    Sprite * background = new Sprite("background.png", Point{1024,768}, Point{0,0});
    Sprite * background2 = new Sprite("background.png", Point{1024,768}, Point{1024,0});
    Sprite * background3 = new Sprite("background.png", Point{1024,768}, Point{2048,0});

    Platform * platform = new Platform("platform.png", Point{200,50}, Point{400,window.getSize().y-50});
    Platform * platform2 = new Platform("platform.png", Point{200,50}, Point{620,(window.getSize().y - 100)});
    Platform * platform3 = new Platform("platform.png", Point{200,50}, Point{840,(window.getSize().y - 50)});

    Resource * life = new Resource("health.png", Point{100,96}, Point{300,700}, 50.0,"health");
    Resource * ammo = new Resource("ammo.png",Point{100,96}, Point{400,700}, 10, "ammo");

    sprites.push_back(background);
    sprites.push_back(background2);
    sprites.push_back(background3);

    enemies.push_back(e);
    enemies.push_back(e2);
    enemies.push_back(e3);

    platforms.push_back(platform);
    platforms.push_back(platform2);
    platforms.push_back(platform3);

    resources.push_back(ammo);
    resources.push_back(life);
}

void GameEngine::startGame(sf::RenderWindow & window)
{
    initGame(window);

    sf::Time time;
    sf::View view;
    view.reset(sf::FloatRect(0,0,window.getSize().x,window.getSize().y));
    view.setViewport(sf::FloatRect(0,0,1.0f,1.0f));
    sf::Vector2f viewPosition(window.getSize().x/2 , window.getSize().y/2);
    while(window.isOpen())
    {
        time = clock.restart();
        sf::Event event;
        while(window.pollEvent(event))
        {

            if(event.type == sf::Event::Closed)
            {
                window.close();
            }
        }


        //Update position of view
        if(player->getPosition().x + (player->getSize().x/2) > window.getSize().x/2 )
        {
            viewPosition.x = player->getPosition().x + (player->getSize().x/2)  ;
        }
        else
        {
            viewPosition.x = (window.getSize().x/2);
        }
        view.setCenter(viewPosition);
        window.setView(view);
        update(window , time.asMilliseconds());

}

}


void GameEngine::update(sf::RenderWindow & window, int time )
{
        render(window, clock.restart().asMilliseconds());


        //Refresh graphics if move is not finished.
        while(player->move(clock.restart().asMilliseconds()) == true)
        {
            render(window, clock.restart().asMilliseconds());
        }

}

void GameEngine::render(sf::RenderWindow & window, int time)
{
    window.clear(sf::Color::Blue);

        Projectile * proj = player->attack();
        if(proj != nullptr)
            projectiles.push_back(proj);

        checkCollisions();


        for(Sprite *    s  : sprites)
        {

            s->drawSprite(window);

        }

        for(Platform* p : platforms)
        {
            p->drawSprite(window);
        }

        for(Enemy * e : enemies)
        {
            e->move(time);
            e->drawSprite(window);
            Projectile * projectile = e->attack();
            if(projectile!=nullptr)
                 enemyProjectiles.push_back(projectile);
        }


        for(Projectile * p : projectiles)
        {
            p->move();
            p->drawSprite(window);
        }
        for(Projectile * p : enemyProjectiles)
        {
            p->move();
            p->drawSprite(window);
        }

        for(Resource * r : resources)
        {
            r->drawSprite(window);
        }

         player->drawSprite(window);
         window.display();

}

void GameEngine::checkCollisions()
{
    int enemyIndex = 0;
    int projectileIndex = 0;

    //Check if enemy gets hit by player
    for(Enemy * enemy: enemies)
    {
        for(Projectile* projectile : projectiles)
        {
            if(enemy->collide(projectile))
            {
                //damage enemy
                enemy->takeDamage(projectile->damage);

                if(enemy->health < 0)
                {
                    enemies.erase(enemies.begin() + enemyIndex);
                    break;
                }
                //Remove projectile
                projectiles.erase(projectiles.begin() + projectileIndex);
                break;
            }
                projectileIndex++;
        }
                enemyIndex++;
    }

    //Check if player gets hit by enemy
       projectileIndex = 0;
       for(Projectile* projectile : enemyProjectiles)
        {
            if(player->collide(projectile))
            {
                //damage enemy
                player->takeDamage(projectile->damage);

                if(player->health < 0)
                {
                    //TODO:: game over
                    break;
                }
                //Remove projectile
                enemyProjectiles.erase(enemyProjectiles.begin() + projectileIndex);
                break;
            }
                projectileIndex++;
        }

        //Check if enemy collide with platform
        for(Platform * platform : platforms)
        {
            player->collide(platform,platforms);
        }

        int resourceIndex  {0};
        for(Resource * resource : resources)
        {
            if(player->collide(resource))
            {
                resources.erase(resources.begin() + resourceIndex);
            }
            resourceIndex++;
        }

    }

