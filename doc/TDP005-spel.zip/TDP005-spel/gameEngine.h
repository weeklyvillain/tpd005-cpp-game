#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include "player.h"
#include "enemy.h"
#include "platform.h"
#include "Resource.h"


class GameEngine
{

public:
    GameEngine();
    void startGame(sf::RenderWindow &);
    void update(sf::RenderWindow &, int);

private:
    void initGame(sf::RenderWindow &);
    void render(sf::RenderWindow &, int);
    void checkCollisions();
    sf::Clock clock;
    std::vector<Sprite*> sprites;
    std::vector<Enemy*> enemies;
    std::vector<Projectile*> projectiles;
    std::vector <Projectile*> enemyProjectiles;
    std::vector <Platform*> platforms;
    std::vector <Resource*> resources;
    Player* player ;


};


