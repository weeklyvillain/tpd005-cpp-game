
Platform::Platform(std::string image, Point size, Point position)
    : Sprite(image,size,position)
    {}

bool Platform::isOnMe(Sprite * object)
{
    return (object->getBottom() <= getTop()  && object->getLeft() <= getRight() && object->getCenterX() >= getLeft());

}
