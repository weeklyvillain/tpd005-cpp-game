#pragma once
#include "sprite.h"

class Platform : public Sprite
{
public:
    Platform(std::string, Point, Point );
    bool isOnMe(Sprite *);

private:


};






#include "platform.cpp"
