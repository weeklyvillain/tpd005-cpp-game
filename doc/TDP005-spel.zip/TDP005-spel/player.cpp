#include <iostream>

Player::Player(std::string image, Point size, Point position)
	:Entity(image,size,position)

{

}


bool Player::move(int time)
{
	time++; //make sure time is not zero


	if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && canMoveRight)
	{
		Point newpos;
		newpos.x = getPosition().x;
		newpos.x +=  (0.2 * time);
		newpos.y = getPosition().y;
		update(newpos);
		return false;
	}
	if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && canMoveLeft)
	{
		Point newpos;
		newpos.x = getPosition().x;
		newpos.x +=  (-0.2 * time);
		newpos.y = getPosition().y;
		update(newpos);
		return false;
	}


	if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space) || jumpAnimationDone == false)
	{
		sf::Clock clock;

		Point newpos;
		newpos.x = getPosition().x;
		newpos.y = getPosition().y;

		jumps++;
		if(jumps == 1)
		{
			jumpAnimationDone = false;
			startHeight = newpos.y;
			frac = (200.0 / float(time));
		}

		if(interruptJump)
		{
		 	jumpDone = false;
			jumpAnimationDone = true;
			jumps = 0;
			startHeight = 0;
			interruptJump = false;
			return false;
		}
		if(jumpDone == false )
		{
		 	newpos.y -= (jumpHeight/frac) ;
		 	update(newpos);
			if(getPosition().y > (startHeight -jumpHeight))
			{
		 	return true;
		 	}
		 	else
		 	{
		 	  jumpDone = true;
		 	  return true;
		 	}
	    	}

	    	else
	    	{
			newpos.y += (jumpHeight/frac) ;
			update(newpos);
	    		if(getPosition().y < startHeight)
	    		{
			return true;
			}
			else
			{
			 jumpDone = false;
			 jumpAnimationDone = true;
			 jumps = 0;
			 startHeight = 0;
			 return false;
			}
		}

		update(newpos);

	}



}

Projectile * Player::attack()
{
	if(sf::Keyboard::isKeyPressed(sf::Keyboard::Z))
	{

	Point entityPosition = getPosition();
	Point spawnPosition = Point{entityPosition.x + getSize().x - 50, (entityPosition.y + (getSize().y /2) -20) };
	Projectile * proj = new Projectile("projectile.png", Point{60.0,50.0}, spawnPosition,1,Point{20.0,0.0});
	return proj;
	}
	else
	 	return nullptr;
}


