#pragma once
#include "entity.h"


class Player : public Entity
{
public:
	Player(std::string , Point, Point);
             Player() = default;
	bool move(int) override;
             Projectile * attack() override;

private:
    float startHeight{0};
    int jumps{0};
    float jumpHeight = 60;
    float frac;
    //true when player reaches max jump height then descend
    bool jumpDone = false;
    bool jumpAnimationDone = true;

protected:

};

#include "player.cpp"
