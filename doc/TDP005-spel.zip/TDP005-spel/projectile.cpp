

Projectile::Projectile(std::string image , Point size, Point position, float damage,Point speed)
	:Sprite(image,size,position), damage{damage}, speed{speed}
{

}

void Projectile::move()
{
	Point newpos;
	newpos.y = getPosition().y;
	newpos.x = getPosition().x +(speed.x);
	update(newpos);
}
