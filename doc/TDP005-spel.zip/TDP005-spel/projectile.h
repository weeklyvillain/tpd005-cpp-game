#pragma once

class Projectile : public Sprite
{
public:
	Projectile(std::string, Point ,Point,float ,Point);
	void move();
	float damage;
	Point speed;
};







#include "projectile.cpp"
