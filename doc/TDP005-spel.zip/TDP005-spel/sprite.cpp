
#include <string>
#include <iostream>

Sprite::Sprite(std::string image, Point size, Point position)
:image{image} , size{size} , position{position}
{
	sf::Texture* tex = new sf::Texture();
	tex->loadFromFile(image);
	texture = tex;
	sprite.setTexture(*tex);
	sprite.setTextureRect(sf::IntRect(0,0,size.x,size.y));
	sprite.setPosition(position.x, position.y);

}

void Sprite::drawSprite(sf::RenderWindow & window)
{
	window.draw(sprite);
}

void Sprite::update(std::string image)
{
	//sf::Texture tex;
	//tex.loadFromFile(image);
//	sprite.setTexture(*texture);
}

void Sprite::update(Point position)
{
	sprite.setPosition(position.x,position.y);
	this->position = position;

}

Point Sprite::getSize()
{
	return size;
}
Point Sprite::getPosition()
{
	return position;
}

float Sprite::getLeft()
{
	return position.x;
}

float Sprite::getRight()
{
	return (position.x + size.x);
}

float Sprite::getTop()
{
	return position.y;
}

float Sprite::getBottom()
{
	return (position.y +size.y);
}

float Sprite::getCenterX()
{
	return (position.x +(size.x/2));
}

float Sprite::getCenterY()
{
	return (position.y +(size.y/2));
}

