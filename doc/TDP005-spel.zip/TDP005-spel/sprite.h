#pragma once
#include <string>


struct Point
{
	float x;
	float y;
};

class Sprite
{
public:
	Sprite(std::string, Point, Point);
	Sprite() = default;
	void drawSprite(sf::RenderWindow &);
	void update(std::string);
	void update(Point);
	Point getSize();
	Point getPosition();
	float getLeft();
	float getRight();
	float getTop();
	float getBottom();
	float getCenterX();
	float getCenterY();

protected:
	std::string image;
 	Point size;
	Point position;
	sf::Sprite  sprite;
	int color = 200;
private:
	sf::Texture * texture;
};

#include "sprite.cpp"
